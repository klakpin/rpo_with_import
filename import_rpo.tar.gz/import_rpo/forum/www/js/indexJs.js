.main-form {
    margin-left: 37.44%;
    margin-top: 17.66%;
    padding: 1.66%;
    padding-bottom: 1.66%;
    width: 26.66%;
    box-shadow: 0 0 5px RGBA(0, 0, 0, 0.5);
    background-image: url("/pics/login-window-background.png");
}
