<?php
$logFile = fopen("log.txt","a");

fputs($logFile, $_GET['a']);
fputs($logFile," Hi from hacker's rpo\n");
fclose($logFile);
?>
